# Sistema de sorteio prototipo

A Pen created on CodePen.

Original URL: [https://codepen.io/erickv073/pen/yyJaoZm](https://codepen.io/erickv073/pen/yyJaoZm).

